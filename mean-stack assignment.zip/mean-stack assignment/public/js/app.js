'use strict';
(function () {
	let app = angular.module('testApp', [ 'angularFileUpload']);
}());