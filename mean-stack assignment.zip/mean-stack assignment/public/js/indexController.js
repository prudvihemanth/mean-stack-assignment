'use strict';
(function () {
	var injectParams = ['$scope','FileUploader'];
	var controller = function ($scope,FileUploader) {

		//global namespace
		$scope.description = '';
		$scope.name = 'Test Assignment On Mean Stack';
		var uploader =  $scope.uploader = new FileUploader({url: 'http://localhost:4321/fileupload'});
		$scope.errorMessage = true;
		$scope.finalOutput = [];

        //update description before the file is added to queue
        uploader.onBeforeUploadItem = function(fileItem) {
        fileItem.formData.push({ desc: $scope.description });
        };

        //after the item is uploaded, get the http response
        uploader.onSuccessItem = function(fileItem, response, status, headers) {
        $scope.finalOutput = response;
        };

       // function to upload the file and clear the queue after upload and reset the form
		$scope.uploadFile = function(){
			if ($scope.uploader.queue.length === 0){
				$scope.errorMessage = false;
				$scope.finalOutput = [];
			}
			else{
				$scope.uploader.queue[0].upload();
                $scope.uploader.queue.length = 0;
                angular.element("input[type='file']").val(null);
                $scope.description = '';
				$scope.errorMessage = 'success';
			}
		};	
	};

    //jquery function for tooltip
	$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
    });

	//bootstrapping
	controller.$inject = injectParams;
	angular.module('testApp').controller('indexController', controller);
}());
