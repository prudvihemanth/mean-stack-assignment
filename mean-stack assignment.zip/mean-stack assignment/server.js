'use strict';

//importing required npm modules
const express = require('express');
const app = express();
const multer  = require('multer');
const fs = require('fs');
let LineByLineReader = require('line-by-line');
const iplocation = require('iplocation')
let dir = 'uploads';

//managing storage for uploaded files
let storage = multer.diskStorage({ destination: (req, file, cb) => { 
    if(!fs.existsSync(dir)){
    fs.mkdirSync(dir);
		}  
    cb(null, dir);	     

 }, filename: (req, file, cb) => { 
     cb(null, file.originalname);
   }});

let upload = multer({ storage: storage });   





//node server connection
const server = app.listen(4321, () => {
	console.log('node web server is listening on port:'+ server.address().port);
});


//serve static files
app.use(express.static('public'));

// end point for file upload
app.post('/fileupload', upload.single('file'),  (req, res) => {

    
let finalArray = [];
let lr = new LineByLineReader(dir+'/'+req.file.originalname);

lr.on('error',  (err) => {
	// 'err' contains error object
});

lr.on('line', (line) => {
let array = line.split(" ");  
if(array.length === 18 && array[3] === '"MATLAB' && array[4] === 'R2013a"'){
    lr.pause();
    //if country is india 
    var ip = array[9].split(':');
    iplocation(ip[0], (error, res) => {
        lr.resume();
        if(res.country_name === 'India'){
            let finalObject = {
                final_output : 'Yes',
                input : line,
                desc : req.body.desc

            }
            finalArray.push(finalObject);
        }
    });
}
else{
let finalObject = {
                final_output : 'No',
                input : line,
                desc : req.body.desc
            }
            finalArray.push(finalObject);
}
});


lr.on('end', () => {
     res.send(finalArray);
});  
});